CSCI 3161 Final Project
By Ruiyang Li B00699529


This is a flight simulation with OpenGL, I write with C.

Create an area (cylinder) including sky and sea with texture.
Generate a plane to fly in the area with given points.
Generate 3 randomly mountains with texture.
Generate normals for mountains per vertex.

Features:
w - toggle between frame mode and solid render mode
f - toggle to fullscreen
b - toggle fog on or off
s - toggle to grid mode
m - toggle to mountains' texture on or off
q - quit

Control:
page up - increate plane speed
page down - decrease plane speed
up - camera up
down - camera down
mouse move left or right: turn plane left or right

Invention:
1. Plane can shoot the bullets, by press space key
2. Random generate the world and replay the simulation, by press r key
3. When the plane fly into the sea, it will explosion

Thank you for your time, hope you enjoy it.